# Tender Price Predictor EXPERIMENTATION TOOL

- `conda create --name <environment_name> --file requirements.txt`
- `pip list --format=freeze > requirements.txt`
