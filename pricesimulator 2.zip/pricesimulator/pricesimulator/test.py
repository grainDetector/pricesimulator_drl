import pickle
import pandas as pd

def load():
    file_path = 'pricesimulator//static//Logit_model_9.pkl'
    with open(file_path, 'rb') as file:
        model = pickle.load(file)
    return model

model = load()
inp = pd.DataFrame()
feat = model.params.index.to_list()
for value in feat:
    print(value)