
from django.shortcuts import render
import pickle
from . import constants
import pandas as pd
import statsmodels.api as sm
from django.http import JsonResponse
import json
import pdb


def load():
    file_path = 'pricesimulator//static//Logit_model_9.pkl'
    with open(file_path, 'rb') as file:
        model = pickle.load(file)
    return model


def home(request):
    if request.method == "GET":
        data = {
            "brand": constants.BRAND,
            "account": constants.ACCOUNT_LIST,
            "city": constants.CITY_LIST,
            "state":constants.STATE_LIST,
            "contract":constants.CONTRACT,
            "month":constants.MONTH,
            "distributor":constants.DISTRIBUTOR,
        }
        return render(request, "home.html",context=data)
    

def loadmodel(Tender,Quantity,Price,Brand,Account,State,City,Duration,Month,Distributor):
            #Input to Model
        model = load()
        # DataFrame
        feat = model.params.index.to_list()
        inp = pd.DataFrame()
        for values in feat:
            inp[values] = [0]


        # Brand 
        brand_value = 'indProduct1'+str(Brand).upper()
        if brand_value in feat:
            inp[str(brand_value)] = [1]
        
        # Account  replace account with lookup
        # Account = constants.Acc[Account]
        account_value = 'ind_'+str(Account)
        if account_value in feat:
            inp[str(account_value)] = [1]

            
        
        # State
        state_value = 'indState1'+str(State).upper()
        if state_value in feat:
            inp[str(state_value)] = [1]
       
       # City
        # city_value = 'indState1'+str(City).upper()
        # if city_value in feat:
        #     inp[str(city_value)] = [1]

        # Duration
        duration_value = 'indPeriod'+str(Duration).replace(' ','_').upper()
        if duration_value in feat:
            inp[str(duration_value)] = [1]
        
        # Month
        month_value = 'indTender'+str(Month).capitalize()
        if month_value in feat:
            inp[str(month_value)] = [1]
        
        # Distributor
        distributor_value = 'indDistributor1'+str(Distributor).replace(' ','_').upper()
        if distributor_value in feat:
            inp[str(distributor_value)] = [1]


        inp['const'] = [1]
        if 'DRLFinalBidPrice1' in feat:
            inp['DRLFinalBidPrice1'] = [float(Price)]

        if 'QTY1' in feat:
            inp['QTY1'] = [float(Quantity)]

        # loading the Model
        model = load()
        prob = model.predict(inp[feat])
        end_result = prob * 100
        probability = round(end_result[0], 2)
        return probability
    
def scenea(request):
    if request.method == "POST":
        data = {
            "brand": constants.BRAND,
            "account": constants.ACCOUNT_LIST,
            "city": constants.CITY_LIST,
            "state":constants.STATE_LIST,
            "contract":constants.CONTRACT,
            "month":constants.MONTH,
            "distributor":constants.DISTRIBUTOR,
        }
        try:
            # Accepting the values
            json_data = json.loads(request.body)

            # Save in Sessions
            for key in ['tender', 'quantity', 'price', 'brand', 'account', 'state', 'city', 'duration', 'month', 'distributor']:
                if key in json_data:
                    request.session[key] = json_data[key]
                else:
                    raise KeyError(f"Key '{key}' not found in json_data.")

            request.session.save()

            # Save to Variables (optional)
            tender = request.session['tender']
            quantity = request.session['quantity']
            price = request.session['price']
            brand = request.session['brand']
            account = request.session['account']
            state = request.session['state']
            city = request.session['city']
            duration = request.session['duration']
            month = request.session['month']
            distributor = request.session['distributor']

            # Revenue and Margin calculation
            revenue = int(quantity) * int(price)
            margin = revenue - (constants.MARGIN[brand.upper()] * int(quantity))

            probability = loadmodel(tender, quantity, price, brand, account, state, city, duration, month, distributor)

            context = {
                'revenue': revenue,
                'margin': margin,
                'probability': probability,
                'price' : price,
            }
            return JsonResponse(context, status=200, safe=False)
        except Exception as e:
            # Handle any exceptions here
            return JsonResponse({'error': str(e)}, status=400)



def ScenarioB(request):
    if request.method == "POST":
        try:
            json_data_b = json.loads(request.body)
            price = json_data_b['price']
            quantity = request.session['quantity']
            brand = request.session['brand']

            # Revenue and Margin calculation
            revenue = int(quantity) * int(price)
            margin = revenue - (constants.MARGIN[brand.upper()] * int(quantity))

            tender2 = request.session['tender']
            account = request.session['account']
            state = request.session['state']
            city = request.session['city']
            duration = request.session['duration']
            month = request.session['month']
            distributor = request.session['distributor']
            prob = loadmodel(tender2, quantity, price, brand, account, state, city, duration, month, distributor)

            context = {
                'revenue': revenue,
                'margin': margin,
                'probability': prob,
                'price' : price
            }

            return JsonResponse(context, status=200, safe=False)
        except KeyError as e:
            return JsonResponse({'error': f"KeyError: {str(e)}"}, status=400)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)

    



# ['const',
#  'indProduct1BORTEZOMIBE',
#  'DRLFinalBidPrice1',
#  'indProduct1FULVESTRANTO',
#  'indProduct1DAPTOMICINA',
#  'indProduct1SUGAMADEX',
#  'indProduct1ABIRATERONA',
#  'indProduct1DECITABINA',
#  'indProduct1AZACITIDINA',
#  'indProduct1FOSAPREPTANTO',
#  'indPeriodDISPENSA']