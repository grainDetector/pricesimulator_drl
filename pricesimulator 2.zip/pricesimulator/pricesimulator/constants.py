ACCOUNT_LIST = ["Amgesp","Base Aerea","Cimero/RO","Cimm-AM P.E","Dasis"]
STATE_LIST = ["AC","AL","AM","BA","CE"]
CITY_LIST = ["Americana","Apiai","Belem","Brasilia","Campinas"]
BRAND = ["Abiraterona","Azacitidina","Bortezomibe","Cabazitaxel","Daptomocina"]
CONTRACT = ["12 Meses","Convite","Dispensa"]
MONTH = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
DISTRIBUTOR = ["Arserve","Atons","Biohosp","Futura","Hospfar"]



# Margin caluculation 


MARGIN  = {
    'ABIRATERONA' : 307 ,
    'AZACITIDINA' : 40,
    'BORTEZOMIBE' : 13,
    'CABAZITAXEL' : 334,
    'CARMUSTINA' : 118,
    'DAPTOMICINA' : 51,
    'DECITABINA' : 165,
    'FOSAPREPTANTO' : 53,
    'FULVESTRANTO' : 132,
    'GEFTINIBE' : 13,
    'LINEZOLIDA' : 7,
    'SUGAMADEX' : 21,
    'VALGANCICLOVIR' : 10,
    'ERLOTINIBE' : 10,
    'SUNITINIBE' : 15,
}
