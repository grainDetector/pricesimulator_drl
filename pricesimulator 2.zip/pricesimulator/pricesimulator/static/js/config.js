$(document).ready(function () {

    $('#sceneb').hide();

    event_configuration = {
        afterChange: btn_activate_start_experimentation,
        addable: function (value) {
            return value
        }
    }

    var ss = new SlimSelect({
        select: '#select-account',
        events: event_configuration
    });

    var ss = new SlimSelect({
        select: '#select-state',
        events: event_configuration
    });

    var ss = new SlimSelect({
        select: '#select-city',
        events: event_configuration
    });

    var ss = new SlimSelect({
        select: '#select-brand',
        events: event_configuration
    });   

    var ss = new SlimSelect({
        select: '#select-duration',
        events: event_configuration
    });  

    var ss = new SlimSelect({
        select: '#select-month',
        events: event_configuration
    });  

    var ss = new SlimSelect({
        select: '#select-distributor',
        events: event_configuration
    });

});


const btn_activate_start_experimentation = () => {
    let tender = $('#tenderName').val(),
        quantity = $('#quantity_input').val(),
        price = $('#price_input').val(),
        account = $("#select-account").val(),
        state = $("#select-state").val(),
        city = $("#select-city").val(),
        brand = $("#select-brand").val(),
        duration = $("#select-duration").val(),
        month = $("#select-month").val(),
        distributor = $("#select-distributor").val();
        if (tender !== "" && quantity !== "" && price !== "" && account !== "" && state !== "" && city !== "" && brand !== "" && duration !== "" && month !== "" && distributor !== "") {
            document.getElementById('btn-start').removeAttribute('disabled');
    } else {
        document.getElementById('btn-start').setAttribute('disabled', 'disabled');
    }
}

function checkInput () {
    var input = document.getElementById("ScenarioB_price").value;
    var button = document.getElementById("btn-startB");
    
    if (input !== "") {
        button.disabled = false;
    } else {
        button.disabled = true;
    }
}
