const csrf_token = Cookies.get('csrftoken');
function clearLocalStorage() {
    localStorage.removeItem('winProbability');
    localStorage.removeItem('marginPrice');
    localStorage.removeItem('price');
  }


$("body")

    .on("click", "#btn-start", function() {
        var tender = $('#tenderName').val().trim();
        var quantity = $('#quantity_input').val().trim();
        var price = $('#price_input').val().trim();
        var account = $('#select-account').val().trim();
        var state = $('#select-state').val().trim();
        var city = $('#select-city').val().trim();
        var brand = $('#select-brand').val().trim();
        var duration = $('#select-duration').val().trim();
        var month = $('#select-month').val().trim();
        var distributor = $('#select-distributor').val().trim();

        clearLocalStorage()
        var final_data = {
            'tender' : tender,
            'quantity' : quantity,
            'price' : price,
            'account' : account,
            'state' : state,
            'city' : city,
            'brand' : brand,
            'duration' : duration,
            'month' : month,
            'distributor' : distributor,
        }
        console.log(final_data)

        $.ajax({
            headers: { 'X-CSRFToken': csrf_token },
            url: "/scenea",
            type: 'POST',
            data: JSON.stringify(final_data),
            contentType: "application/json",
            success: function (result) {
                $('#sceneb').show();
                var revenue = result.revenue;
                var margin = result.margin;
                var newprice = parseInt(result.price);
                var probability = result.probability;


                var winProbability = JSON.parse(localStorage.getItem('winProbability')) || [];
                var marginPrice = JSON.parse(localStorage.getItem('marginPrice')) || [];
                var price = JSON.parse(localStorage.getItem('price')) || [];

                winProbability.push(probability);
                marginPrice.push(margin);
                price.push(newprice);
            
                // Store updated arrays in local storage
                localStorage.setItem('winProbability', JSON.stringify(winProbability));
                localStorage.setItem('marginPrice', JSON.stringify(marginPrice));
                localStorage.setItem('price', JSON.stringify(price));

                
              var trace1 = {
                x: price, // Assuming categories are represented by keys
                y: winProbability,
                name: 'Win Probability (%)',
                type: 'scatter',
                yaxis: 'y1'
              };
          
              var trace2 = {
                x: price, // Assuming categories are represented by keys
                y: marginPrice,
                name: 'Margin Price',
                type: 'scatter',
                yaxis: 'y2'
              };
          
              // Layout
              var layout = {
                title: 'Win Probability vs. Margin Price',
                yaxis: {title: 'Win Probability (%)', side: 'left', range: [0, 100]}, // Left y-axis for win probability
                yaxis2: {title: 'Margin Price', overlaying: 'y', side: 'right'}, // Right y-axis for margin price
                xaxis: {title: 'Price'} // X-axis label
              };
          
              var data = [trace1, trace2];
          
              // Plot the line chart
              Plotly.newPlot('line-chart', data, layout);
                var data = [
                    {
                      x: ['Revenue', 'Margin'],
                      y: [revenue, margin],
                      type: 'bar',
                      marker: {
                        color: ['blue', '#0dcaf0']
                      },
                      text: [revenue.toString(), margin.toString()],
                      textposition: 'auto',
                      textfont: {
                        size: 14,
                        color: 'black' // Color of the text
                      }
                    }
                  ];
                  bar_width = 0.5
                  // Set layout
                  var layout = {
                    yaxis: {title: 'Unit Price'}
                  };
                
                  // Plot the bar graph
                  Plotly.newPlot('bar-chart', data, layout);
                  var winnerText = `<span class="f-ptSans-bold fs-16 text-secondary text-center">Win Probability</span> <br> `+ result.probability;
                    document.getElementById("info-box").innerHTML = winnerText;
                    
            }
        });
    })


    .on("click", "#btn-startB", function() {
      var price = $('#ScenarioB_price').val().trim();
      var final_data_b = {
          'price' : price,
      };
      $.ajax({
          headers: { 'X-CSRFToken': csrf_token },
          url: "/ScenarioB",
          type: 'POST',
          data: JSON.stringify(final_data_b),
          contentType: "application/json",
          success: function (result) {
              var newprice = parseInt(result.price);
              var margin = result.margin;
              var probability = result.probability
              var revenue = result.revenue;


              var winProbability = JSON.parse(localStorage.getItem('winProbability')) || [];
              var marginPrice = JSON.parse(localStorage.getItem('marginPrice')) || [];
              var price2 = JSON.parse(localStorage.getItem('price')) || [];

              winProbability.push(probability);
              marginPrice.push(margin);
              price2.push(newprice);
          
              // Store updated arrays in local storage
              localStorage.setItem('winProbability', JSON.stringify(winProbability));
              localStorage.setItem('marginPrice', JSON.stringify(marginPrice));
              localStorage.setItem('price', JSON.stringify(price2));


              var trace1 = {
                x: price2, // Assuming categories are represented by keys
                y: winProbability,
                name: 'Win Probability (%)',
                type: 'scatter',
                yaxis: 'y1'
              };
          
              var trace2 = {
                x: price2, // Assuming categories are represented by keys
                y: marginPrice,
                name: 'Margin Price',
                type: 'scatter',
                yaxis: 'y2'
              };
          
              // Layout
              var layout = {
                title: 'Win Probability vs. Margin Price',
                yaxis: {title: 'Win Probability (%)', side: 'left', range: [0, 100]}, // Left y-axis for win probability
                yaxis2: {title: 'Margin Price', overlaying: 'y', side: 'right'}, // Right y-axis for margin price
                xaxis: {title: 'Price'} // X-axis label
              };
          
              var data = [trace1, trace2];
          
              // Plot the line chart
              Plotly.newPlot('line-chart', data, layout);
              


              var data = [
                  {
                      x: ['Revenue', 'Margin'],
                      y: [revenue, margin],
                      type: 'bar',
                      marker: {
                          color: ['blue', '#0dcaf0']
                      },
                      text: [revenue.toString(), margin.toString()],
                      textposition: 'auto',
                      textfont: {
                          size: 14,
                          color: 'black' // Color of the text
                      }
                  }
              ];
              bar_width = 0.5
              var layout = {
                  yaxis: {title: 'Unit Price'}
              };
              Plotly.newPlot('bar-chart2', data, layout);
              var winnerText = `<span class="f-ptSans-bold fs-16 text-secondary text-center">Win Probability</span> <br> `+ result.probability;
              document.getElementById("info-box2").innerHTML = winnerText;

          },
          error: function(xhr, status, error) {
              // Handle errors
              console.error(xhr.responseText);
              // Optionally, you can provide feedback to the user about the error
          }
      });
  })
  
  .on("click", "#btn-reset", function() {
    clearLocalStorage();
    location.reload(true);
})